"""
app.py
Main Flask application for the Rental Management System.
"""

import os
import re
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from mysql.connector import Error

from db import get_connection

app = Flask(__name__)
app.secret_key = "change-this-secret-key-in-production"

# ----------------------------------------------------
# Config
# ----------------------------------------------------
UPLOAD_FOLDER = os.path.join("static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB max upload

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ----------------------------------------------------
# Helpers
# ----------------------------------------------------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def is_valid_phone(phone):
    """Accepts 10-digit Indian phone numbers, optionally prefixed with +91."""
    pattern = r"^(\+91[\-\s]?)?[6-9]\d{9}$"
    return re.match(pattern, phone.strip()) is not None


def save_uploaded_image(file):
    """Saves an uploaded image with a unique filename. Returns the filename or None."""
    if file and file.filename and allowed_file(file.filename):
        ext = file.filename.rsplit(".", 1)[1].lower()
        unique_name = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
        file.save(filepath)
        return unique_name
    return None


def delete_image_file(filename):
    if filename:
        path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        if os.path.exists(path):
            os.remove(path)


def validate_property_form(form, files, property_id=None):
    """
    Validates the add/edit property form.
    Returns a list of error messages (empty list if valid).
    """
    errors = []

    name = form.get("property_name", "").strip()
    property_type = form.get("property_type", "").strip()
    city = form.get("city", "").strip()
    address = form.get("address", "").strip()
    rent = form.get("rent", "").strip()
    status = form.get("status", "").strip()
    owner_name = form.get("owner_name", "").strip()
    owner_phone = form.get("owner_phone", "").strip()

    # Required fields
    required = {
        "Property name": name,
        "Property type": property_type,
        "City": city,
        "Address": address,
        "Rent": rent,
        "Status": status,
        "Owner name": owner_name,
        "Owner phone": owner_phone,
    }
    for label, value in required.items():
        if not value:
            errors.append(f"{label} is required.")

    # Rent must be a positive number
    if rent:
        try:
            rent_value = float(rent)
            if rent_value <= 0:
                errors.append("Rent must be a positive number.")
        except ValueError:
            errors.append("Rent must be a valid number.")

    # Phone validation
    if owner_phone and not is_valid_phone(owner_phone):
        errors.append("Owner phone must be a valid 10-digit Indian phone number.")

    # Property type / status sanity check
    if property_type and property_type not in ("Villa", "Apartment"):
        errors.append("Property type must be Villa or Apartment.")
    if status and status not in ("Available", "Occupied"):
        errors.append("Status must be Available or Occupied.")

    # Duplicate name check (only if name provided)
    if name:
        conn = get_connection()
        cursor = conn.cursor()
        if property_id:
            cursor.execute(
                "SELECT id FROM properties WHERE property_name = %s AND id != %s",
                (name, property_id),
            )
        else:
            cursor.execute(
                "SELECT id FROM properties WHERE property_name = %s", (name,)
            )
        existing = cursor.fetchone()
        cursor.close()
        conn.close()
        if existing:
            errors.append(f'A property named "{name}" already exists.')

    # Image type validation (only if a file was actually uploaded)
    image_file = files.get("property_image")
    if image_file and image_file.filename:
        if not allowed_file(image_file.filename):
            errors.append("Image must be a PNG, JPG, JPEG, GIF, or WEBP file.")

    return errors


# ----------------------------------------------------
# Routes
# ----------------------------------------------------
@app.route("/")
def index():
    """Dashboard: stats cards + property list with filters."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    # --- Read filter params ---
    f_type = request.args.get("property_type", "").strip()
    f_city = request.args.get("city", "").strip()
    f_status = request.args.get("status", "").strip()
    f_min_rent = request.args.get("min_rent", "").strip()
    f_max_rent = request.args.get("max_rent", "").strip()

    query = "SELECT * FROM properties WHERE 1=1"
    params = []

    if f_type:
        query += " AND property_type = %s"
        params.append(f_type)
    if f_city:
        query += " AND city = %s"
        params.append(f_city)
    if f_status:
        query += " AND status = %s"
        params.append(f_status)
    if f_min_rent:
        try:
            query += " AND rent >= %s"
            params.append(float(f_min_rent))
        except ValueError:
            pass
    if f_max_rent:
        try:
            query += " AND rent <= %s"
            params.append(float(f_max_rent))
        except ValueError:
            pass

    query += " ORDER BY created_at DESC"
    cursor.execute(query, tuple(params))
    properties = cursor.fetchall()

    # --- Stats (always computed on the FULL table, not filtered) ---
    cursor.execute("SELECT COUNT(*) AS total FROM properties")
    total_properties = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE property_type = 'Villa'")
    total_villas = cursor.fetchone()["c"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE property_type = 'Apartment'")
    total_apartments = cursor.fetchone()["c"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE status = 'Available'")
    total_available = cursor.fetchone()["c"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE status = 'Occupied'")
    total_occupied = cursor.fetchone()["c"]

    cursor.execute(
        "SELECT COALESCE(SUM(rent), 0) AS total_income FROM properties WHERE status = 'Occupied'"
    )
    total_income = cursor.fetchone()["total_income"]

    # --- Distinct cities for filter dropdown ---
    cursor.execute("SELECT DISTINCT city FROM properties ORDER BY city")
    cities = [row["city"] for row in cursor.fetchall()]

    cursor.close()
    conn.close()

    stats = {
        "total_properties": total_properties,
        "total_villas": total_villas,
        "total_apartments": total_apartments,
        "total_available": total_available,
        "total_occupied": total_occupied,
        "total_income": total_income,
    }

    active_filters = {
        "property_type": f_type,
        "city": f_city,
        "status": f_status,
        "min_rent": f_min_rent,
        "max_rent": f_max_rent,
    }

    return render_template(
        "index.html",
        properties=properties,
        stats=stats,
        cities=cities,
        filters=active_filters,
    )


@app.route("/add", methods=["GET", "POST"])
def add_property():
    """Add a new property."""
    if request.method == "POST":
        errors = validate_property_form(request.form, request.files)

        if errors:
            for err in errors:
                flash(err, "error")
            return render_template("add.html", form_data=request.form)

        image_filename = save_uploaded_image(request.files.get("property_image"))

        conn = get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO properties
                (property_name, property_type, city, address, rent, status,
                 owner_name, owner_phone, image_filename)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    request.form["property_name"].strip(),
                    request.form["property_type"].strip(),
                    request.form["city"].strip(),
                    request.form["address"].strip(),
                    float(request.form["rent"]),
                    request.form["status"].strip(),
                    request.form["owner_name"].strip(),
                    request.form["owner_phone"].strip(),
                    image_filename,
                ),
            )
            conn.commit()
            flash("Property added successfully.", "success")
            return redirect(url_for("index"))
        except Error as e:
            conn.rollback()
            flash(f"Database error: {e}", "error")
            return render_template("add.html", form_data=request.form)
        finally:
            cursor.close()
            conn.close()

    return render_template("add.html", form_data={})


@app.route("/edit/<int:property_id>", methods=["GET", "POST"])
def edit_property(property_id):
    """Edit an existing property."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM properties WHERE id = %s", (property_id,))
    property_row = cursor.fetchone()

    if not property_row:
        cursor.close()
        conn.close()
        flash("Property not found.", "error")
        return redirect(url_for("index"))

    if request.method == "POST":
        errors = validate_property_form(request.form, request.files, property_id=property_id)

        if errors:
            for err in errors:
                flash(err, "error")
            cursor.close()
            conn.close()
            # Merge submitted values back in so the form keeps user input
            merged = dict(property_row)
            merged.update(request.form)
            return render_template("edit.html", property=merged)

        new_image_filename = property_row["image_filename"]
        uploaded_file = request.files.get("property_image")
        if uploaded_file and uploaded_file.filename:
            saved_name = save_uploaded_image(uploaded_file)
            if saved_name:
                delete_image_file(property_row["image_filename"])
                new_image_filename = saved_name

        try:
            update_cursor = conn.cursor()
            update_cursor.execute(
                """
                UPDATE properties
                SET property_name=%s, property_type=%s, city=%s, address=%s,
                    rent=%s, status=%s, owner_name=%s, owner_phone=%s, image_filename=%s
                WHERE id=%s
                """,
                (
                    request.form["property_name"].strip(),
                    request.form["property_type"].strip(),
                    request.form["city"].strip(),
                    request.form["address"].strip(),
                    float(request.form["rent"]),
                    request.form["status"].strip(),
                    request.form["owner_name"].strip(),
                    request.form["owner_phone"].strip(),
                    new_image_filename,
                    property_id,
                ),
            )
            conn.commit()
            update_cursor.close()
            flash("Property updated successfully.", "success")
            return redirect(url_for("index"))
        except Error as e:
            conn.rollback()
            flash(f"Database error: {e}", "error")
        finally:
            cursor.close()
            conn.close()
        return redirect(url_for("index"))

    cursor.close()
    conn.close()
    return render_template("edit.html", property=property_row)


@app.route("/delete/<int:property_id>", methods=["POST"])
def delete_property(property_id):
    """Delete a property (confirmation handled client-side via JS modal)."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT image_filename FROM properties WHERE id = %s", (property_id,))
    row = cursor.fetchone()

    if not row:
        cursor.close()
        conn.close()
        flash("Property not found.", "error")
        return redirect(url_for("index"))

    delete_cursor = conn.cursor()
    try:
        delete_cursor.execute("DELETE FROM properties WHERE id = %s", (property_id,))
        conn.commit()
        delete_image_file(row["image_filename"])
        flash("Property deleted successfully.", "success")
    except Error as e:
        conn.rollback()
        flash(f"Database error: {e}", "error")
    finally:
        cursor.close()
        delete_cursor.close()
        conn.close()

    return redirect(url_for("index"))


@app.route("/statistics")
def statistics():
    """Dedicated statistics page."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT COALESCE(SUM(rent), 0) AS total_income FROM properties WHERE status = 'Occupied'"
    )
    total_income = cursor.fetchone()["total_income"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE status = 'Available'")
    total_available = cursor.fetchone()["c"]

    cursor.execute("SELECT COUNT(*) AS c FROM properties WHERE status = 'Occupied'")
    total_occupied = cursor.fetchone()["c"]

    cursor.execute(
        "SELECT city, COUNT(*) AS count FROM properties GROUP BY city ORDER BY count DESC"
    )
    by_city = cursor.fetchall()

    cursor.execute(
        "SELECT property_type, COUNT(*) AS count FROM properties GROUP BY property_type"
    )
    by_type = cursor.fetchall()

    cursor.close()
    conn.close()

    stats = {
        "total_income": total_income,
        "total_available": total_available,
        "total_occupied": total_occupied,
        "by_city": by_city,
        "by_type": by_type,
    }
    return render_template("statistics.html", stats=stats)


if __name__ == "__main__":
    app.run(debug=True)
