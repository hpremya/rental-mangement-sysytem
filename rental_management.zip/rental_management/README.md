# 🏠 RentalHub — Rental Management System

A full-stack rental property management web app built with **Flask**, **MySQL**, and **vanilla HTML/CSS/JS**. Manage properties, track occupancy, view income statistics, and filter listings — all through a clean, responsive UI.

---

## ✨ Features

- **Dashboard** with live stat cards: Total Properties, Villas, Apartments, Available, Occupied
- **Add / Edit / Delete** properties with image upload + thumbnail previews
- **Filters**: property type, city, rent range, status
- **Validation**: required fields, positive rent, Indian phone number format, duplicate property name check
- **Delete confirmation modal** (no accidental deletes)
- **Flash messages** for success/error feedback
- **Statistics page**: total rental income, available vs occupied breakdown, by-city and by-type breakdown
- **Fully responsive** UI with a collapsible navbar for mobile

---

## 🗂 Project Structure

```
rental_management/
│
├── app.py                  # Main Flask application (routes, validation, logic)
├── db.py                   # MySQL connection helper
├── rental_management.sql   # Database schema + sample data
├── requirements.txt        # Python dependencies
├── README.md
│
├── templates/
│   ├── base.html            # Shared layout: navbar, flash messages, footer
│   ├── index.html           # Dashboard: stat cards, filters, property grid, delete modal
│   ├── add.html             # Add property form
│   ├── edit.html            # Edit property form
│   └── statistics.html      # Statistics page
│
└── static/
    ├── css/style.css        # All styling (responsive, design system)
    ├── js/script.js         # Navbar toggle, image preview, delete modal, flash autohide
    └── uploads/             # Uploaded property images land here
```

---

## 🧱 Database Schema

**Database:** `rental_management`
**Table:** `properties`

| Column          | Type                              | Notes                              |
|-----------------|------------------------------------|-------------------------------------|
| id              | INT, AUTO_INCREMENT, PRIMARY KEY  |                                      |
| property_name   | VARCHAR(100), UNIQUE, NOT NULL    | duplicate names rejected at app level too |
| property_type   | ENUM('Villa','Apartment')         |                                      |
| city            | VARCHAR(50)                       |                                      |
| address         | VARCHAR(255)                      |                                      |
| rent            | DECIMAL(10,2), CHECK (rent > 0)   |                                      |
| status          | ENUM('Available','Occupied')      | default `Available`                 |
| owner_name      | VARCHAR(100)                      |                                      |
| owner_phone     | VARCHAR(15)                       | validated as Indian mobile number   |
| image_filename  | VARCHAR(255), nullable            | stored in `static/uploads/`         |
| created_at      | TIMESTAMP                         | auto-set on insert                  |
| updated_at      | TIMESTAMP                         | auto-updated on edit                |

See [`rental_management.sql`](./rental_management.sql) for the full DDL + 4 sample rows.

---

## 🔄 Project Flow

1. **User lands on Dashboard (`/`)**
   → Flask queries `properties` table → computes stats (counts by type/status, total income) → renders `index.html` with stat cards + property grid.

2. **User applies filters** (type / city / rent range / status)
   → Form submits as `GET` query params → `app.py` builds a dynamic `WHERE` clause → re-renders the filtered grid (stat cards stay based on the full table, not the filtered view).

3. **User clicks "Add Property"** (`/add`)
   → GET shows blank form → POST runs `validate_property_form()` (required fields, rent > 0, phone regex, duplicate name check, image type check) → on success, image is saved to `static/uploads/` with a UUID filename, row is inserted, flash message shown, redirect to dashboard. On failure, errors are flashed and the form re-renders with the user's input preserved.

4. **User clicks "Edit"** on a property card (`/edit/<id>`)
   → Same validation flow as Add, but excludes the current row from the duplicate-name check and only replaces the image if a new file is uploaded (old image is deleted from disk).

5. **User clicks "Delete"**
   → JS opens a confirmation modal (`openDeleteModal()`) showing the property name → on confirm, a `POST` request hits `/delete/<id>` → row + associated image file are deleted → flash message shown.

6. **User visits Statistics** (`/statistics`)
   → Aggregates total income (sum of rent where status = Occupied), available/occupied counts, and group-by breakdowns for city and property type.

---

## ⚙️ Installation — Step by Step

### Prerequisites
- Python 3.9+
- MySQL Server 8.0+ (or MariaDB)
- pip

### Step 1 — Get the project files
Download/clone all files into a folder, e.g. `rental_management/`.

### Step 2 — Create a virtual environment (recommended)
```bash
cd rental_management
python -m venv venv

# Activate it:
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

### Step 3 — Install Python dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Set up the MySQL database
Open a terminal/MySQL client and run:
```bash
mysql -u root -p < rental_management.sql
```
This creates the `rental_management` database, the `properties` table, and inserts 4 sample rows.

> If you prefer the MySQL shell directly:
> ```sql
> SOURCE /full/path/to/rental_management.sql;
> ```

### Step 5 — Configure your database credentials
Open `db.py` and update:
```python
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "YOUR_MYSQL_PASSWORD",
    "database": "rental_management"
}
```

### Step 6 — Run the app
```bash
python app.py
```

### Step 7 — Open in browser
Go to:
```
http://127.0.0.1:5000/
```

You should see the Dashboard with 4 sample properties already loaded. 🎉

---

## 🛠 Troubleshooting

| Problem | Fix |
|---|---|
| `mysql.connector.errors.ProgrammingError: Access denied` | Double-check username/password in `db.py` |
| `Unknown database 'rental_management'` | Re-run Step 4 — the `.sql` file wasn't imported |
| Images not showing | Make sure `static/uploads/` exists and is writable (Flask auto-creates it on first run) |
| `ModuleNotFoundError: No module named 'flask'` | Activate your virtual environment, then re-run `pip install -r requirements.txt` |
| Port 5000 already in use | Run `app.run(debug=True, port=5001)` in `app.py` and visit that port instead |

---

## 📸 Screenshots

> Add your own screenshots here after running the app locally. Suggested shots:
> - Dashboard with stat cards + property grid
> - Add Property form with image upload
> - Filter panel in use
> - Delete confirmation modal
> - Statistics page
>
> Example markdown once you have images saved in a `screenshots/` folder:
> ```markdown
> ![Dashboard](screenshots/dashboard.png)
> ![Add Property](screenshots/add_property.png)
> ![Statistics](screenshots/statistics.png)
> ```

---

## 🚀 Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: RentalHub rental management system"
git branch -M main
git remote add origin https://github.com/<your-username>/rental-management-system.git
git push -u origin main
```

> Tip: add a `.gitignore` with `venv/`, `__pycache__/`, and `static/uploads/*` (keep a `.gitkeep` file there) so you don't commit your virtual environment or uploaded test images.

---

## 🧰 Tech Stack

- **Backend:** Flask (Python)
- **Database:** MySQL
- **Frontend:** HTML5, CSS3 (custom design system, no framework), vanilla JavaScript
- **Image handling:** Werkzeug secure filename + UUID-based storage

---

## 📄 License

Free to use and modify for personal or academic projects.
