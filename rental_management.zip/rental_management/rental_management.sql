-- ============================================
-- Rental Management System - Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS rental_management;
USE rental_management;

DROP TABLE IF EXISTS properties;

CREATE TABLE properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_name VARCHAR(100) NOT NULL UNIQUE,
    property_type ENUM('Villa', 'Apartment') NOT NULL,
    city VARCHAR(50) NOT NULL,
    address VARCHAR(255) NOT NULL,
    rent DECIMAL(10,2) NOT NULL CHECK (rent > 0),
    status ENUM('Available', 'Occupied') NOT NULL DEFAULT 'Available',
    owner_name VARCHAR(100) NOT NULL,
    owner_phone VARCHAR(15) NOT NULL,
    image_filename VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO properties
(property_name, property_type, city, address, rent, status, owner_name, owner_phone, image_filename)
VALUES
('Green Valley Villa', 'Villa', 'Coimbatore', '12 Green Valley Road', 45000.00, 'Available', 'Ramesh Kumar', '9876543210', NULL),
('Sunshine Apartments 2B', 'Apartment', 'Chennai', '45 Anna Nagar', 18000.00, 'Occupied', 'Priya Raj', '9123456780', NULL),
('Lakeview Villa', 'Villa', 'Bangalore', '7 Lake View Layout', 60000.00, 'Available', 'Suresh Babu', '9988776655', NULL),
('Palm Residency 3A', 'Apartment', 'Coimbatore', '22 RS Puram', 15000.00, 'Occupied', 'Anita Selvam', '9090909090', NULL);
