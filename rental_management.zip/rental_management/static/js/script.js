/* ============================================
   RentalHub — script.js
   ============================================ */

// ---------- Mobile navbar toggle ----------
document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("navToggle");
    const links = document.getElementById("navLinks");

    if (toggle && links) {
        toggle.addEventListener("click", function () {
            links.classList.toggle("open");
        });
    }

    // ---------- Auto-hide flash messages ----------
    document.querySelectorAll(".flash-message[data-autohide='true']").forEach(function (msg) {
        setTimeout(function () {
            msg.style.transition = "opacity 300ms ease";
            msg.style.opacity = "0";
            setTimeout(function () { msg.remove(); }, 300);
        }, 4500);
    });
});

// ---------- Image preview for upload boxes ----------
function setupImagePreview(inputId, previewId, placeholderId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const placeholder = document.getElementById(placeholderId);

    if (!input || !preview) return;

    input.addEventListener("change", function () {
        const file = input.files && input.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = "block";
            if (placeholder) placeholder.style.display = "none";
        };
        reader.readAsDataURL(file);
    });
}

// ---------- Delete confirmation modal ----------
function openDeleteModal(propertyId, propertyName) {
    const modal = document.getElementById("deleteModal");
    const nameSpan = document.getElementById("deletePropertyName");
    const form = document.getElementById("deleteForm");

    if (!modal || !form) return;

    nameSpan.textContent = propertyName;
    form.action = "/delete/" + propertyId;
    modal.classList.add("active");
}

function closeDeleteModal() {
    const modal = document.getElementById("deleteModal");
    if (modal) modal.classList.remove("active");
}

// Close modal when clicking outside the box
document.addEventListener("click", function (e) {
    const modal = document.getElementById("deleteModal");
    if (modal && e.target === modal) {
        modal.classList.remove("active");
    }
});

// Close modal with Escape key
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
        closeDeleteModal();
    }
});
