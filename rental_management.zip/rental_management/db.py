"""
db.py
Handles the MySQL database connection for the Rental Management System.
"""

import mysql.connector
from mysql.connector import Error


DB_CONFIG = {
    "host": "localhost",
    "user": "root",          # change to your MySQL username
    "password": "",          # change to your MySQL password
    "database": "rental_management"
}


def get_connection():
    """
    Creates and returns a new MySQL connection.
    Raises an exception if the connection fails so the caller can handle it.
    """
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        print(f"[DB ERROR] Could not connect to MySQL: {e}")
        raise
